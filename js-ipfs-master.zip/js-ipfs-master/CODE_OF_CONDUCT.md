# Contributor Code of Conduct

The `js-ipfs` project follows the [`IPFS Community Code of Conduct`](https://github.com/ipfs/community/blob/master/code-of-conduct.md)
