'use strict'

module.exports = (server) => {
  require('./gateway')(server)
}
