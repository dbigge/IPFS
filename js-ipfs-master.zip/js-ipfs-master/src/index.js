'use strict'

const IPFS = require('./core')

exports = module.exports = IPFS
