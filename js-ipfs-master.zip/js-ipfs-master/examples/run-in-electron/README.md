# js-ipfs in Electron

> This example is heavily inspired by [electron-quick-start](https://github.com/electron/electron-quick-start).

To try it by yourself, do:

```
> npm install
> ./node_modules/.bin/electron-rebuild
# or 
> ./build.sh
#
# You can also try to use `npm start` to see where electron errors
```
